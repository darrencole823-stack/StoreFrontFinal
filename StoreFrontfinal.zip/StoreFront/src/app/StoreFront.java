
package app;

import java.util.Scanner;

/**
 * Main application for the Store Front.
 * Allows users to view inventory, purchase products,
 * cancel purchases, view their shopping cart,
 * and sort products by name or price.
 *
 * Also starts the Administration Service
 * on a background thread.
 */
public class StoreFront {

    /**
     * Starts the Store Front application.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        InventoryManager inventory = new InventoryManager();
        ShoppingCart cart = new ShoppingCart();

        // Load inventory from the external JSON file
        inventory.initializeInventory();
        cart.initializeCart();

        // Start the Administration Service in the background
        AdminService adminService =
                new AdminService(inventory, 5000);

        Thread adminThread = new Thread(adminService);
        adminThread.setDaemon(true);
        adminThread.start();

        int choice = 0;

        System.out.println("Welcome to the Game Store!");

        while (choice != 9) {

            System.out.println("\n1. View Inventory");
            System.out.println("2. Purchase Product");
            System.out.println("3. Cancel Purchase");
            System.out.println("4. View Shopping Cart");
            System.out.println("5. Sort Name A to Z");
            System.out.println("6. Sort Name Z to A");
            System.out.println("7. Sort Price Low to High");
            System.out.println("8. Sort Price High to Low");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");

            if (!input.hasNextInt()) {
                System.out.println("Invalid entry. Please enter a number.");
                input.next();
                continue;
            }

            choice = input.nextInt();

            if (choice == 1) {

                inventory.displayInventory();

            } else if (choice == 2) {

                inventory.displayInventory();
                System.out.print("Enter product number: ");

                if (!input.hasNextInt()) {
                    System.out.println("Invalid product number.");
                    input.next();
                    continue;
                }

                int number = input.nextInt();
                SalableProduct product = inventory.getProduct(number);

                if (product == null) {
                    System.out.println("Product not found.");

                } else if (product.getQuantity() > 0) {

                    product.setQuantity(product.getQuantity() - 1);

                    product.setPurchasedQuantity(
                            product.getPurchasedQuantity() + 1);

                    cart.addProduct(product);

                    System.out.println("Purchased: "
                            + product.getName());

                } else {

                    System.out.println("Product is out of stock.");
                }

            } else if (choice == 3) {

                if (cart.getCart().isEmpty()) {
                    System.out.println("Your shopping cart is empty.");
                    continue;
                }

                System.out.println("\nShopping Cart:");

                for (int i = 0; i < cart.getCart().size(); i++) {
                    System.out.println((i + 1) + ". "
                            + cart.getCart().get(i).getName());
                }

                System.out.print("Enter product number to cancel: ");

                if (!input.hasNextInt()) {
                    System.out.println("Invalid product number.");
                    input.next();
                    continue;
                }

                int number = input.nextInt();

                if (number < 1 || number > cart.getCart().size()) {

                    System.out.println("Product not found.");

                } else {

                    SalableProduct product =
                            cart.getCart().get(number - 1);

                    cart.removeProduct(product);

                    product.setQuantity(product.getQuantity() + 1);

                    product.setPurchasedQuantity(
                            product.getPurchasedQuantity() - 1);

                    System.out.println("Purchase canceled: "
                            + product.getName());
                }

            } else if (choice == 4) {

                System.out.println("\nShopping Cart:");

                if (cart.getCart().isEmpty()) {

                    System.out.println("Your shopping cart is empty.");

                } else {

                    for (int i = 0; i < cart.getCart().size(); i++) {

                        SalableProduct product =
                                cart.getCart().get(i);

                        System.out.println((i + 1) + ". "
                                + product.getName()
                                + " - $" + product.getPrice());
                    }
                }

            } else if (choice == 5) {

                inventory.sortNameAscending();
                System.out.println("\nProducts sorted by name A to Z.");
                inventory.displayInventory();

            } else if (choice == 6) {

                inventory.sortNameDescending();
                System.out.println("\nProducts sorted by name Z to A.");
                inventory.displayInventory();

            } else if (choice == 7) {

                inventory.sortPriceAscending();
                System.out.println("\nProducts sorted by price Low to High.");
                inventory.displayInventory();

            } else if (choice == 8) {

                inventory.sortPriceDescending();
                System.out.println("\nProducts sorted by price High to Low.");
                inventory.displayInventory();

            } else if (choice == 9) {

                System.out.println(
                        "Thank you for visiting the Game Store!");

            } else {

                System.out.println(
                        "Invalid choice. Please try again.");
            }
        }

        input.close();
    }
}
