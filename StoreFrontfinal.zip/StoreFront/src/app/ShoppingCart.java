package app;

import java.util.ArrayList;

/**
 * Manages the shopping cart for the Store Front.
 */
public class ShoppingCart {

    private ArrayList<SalableProduct> cart = new ArrayList<>();

    /**
     * Initializes the shopping cart.
     */
    public void initializeCart() {
        cart.clear();
    }

    /**
     * Adds a product to the shopping cart.
     *
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) {
        cart.add(product);
    }

    /**
     * Removes a product from the shopping cart.
     *
     * @param product Product to remove
     */
    public void removeProduct(SalableProduct product) {
        cart.remove(product);
    }

    /**
     * Returns all products in the shopping cart.
     *
     * @return Shopping cart products
     */
    public ArrayList<SalableProduct> getCart() {
        return cart;
    }

    /**
     * Empties the shopping cart.
     */
    public void emptyCart() {
        cart.clear();
    }
}