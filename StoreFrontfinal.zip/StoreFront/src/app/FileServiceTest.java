
package app;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.google.gson.JsonParseException;

/**
 * JUnit tests for the FileService class.
 */
public class FileServiceTest {

    private FileService fileService;
    private ArrayList<SalableProduct> products;

    @TempDir
    Path tempFolder;

    @BeforeEach
    public void setUp() {
        fileService = new FileService();
        products = new ArrayList<>();

        products.add(new Weapon(
                "Sword", "Basic sword", 25.00, 10));

        products.add(new Armor(
                "Shield", "Basic shield", 30.00, 5));

        products.add(new Health(
                "Potion", "Restores health", 15.00, 20));
    }

    @Test
    public void testSaveInventory() throws IOException {
        Path file = tempFolder.resolve("inventory.json");

        fileService.saveInventory(file.toString(), products);

        assertTrue(Files.exists(file));
        assertTrue(Files.size(file) > 0);
    }

    @Test
    public void testLoadInventory() throws IOException {
        Path file = tempFolder.resolve("inventory.json");

        fileService.saveInventory(file.toString(), products);

        ArrayList<SalableProduct> loaded =
                fileService.loadInventory(file.toString());

        assertEquals(3, loaded.size());
        assertEquals("Sword", loaded.get(0).getName());
        assertEquals("Shield", loaded.get(1).getName());
        assertEquals("Potion", loaded.get(2).getName());
    }

    @Test
    public void testLoadProductTypes() throws IOException {
        Path file = tempFolder.resolve("inventory.json");

        fileService.saveInventory(file.toString(), products);

        ArrayList<SalableProduct> loaded =
                fileService.loadInventory(file.toString());

        assertInstanceOf(Weapon.class, loaded.get(0));
        assertInstanceOf(Armor.class, loaded.get(1));
        assertInstanceOf(Health.class, loaded.get(2));
    }

    @Test
    public void testLoadProductValues() throws IOException {
        Path file = tempFolder.resolve("inventory.json");

        fileService.saveInventory(file.toString(), products);

        ArrayList<SalableProduct> loaded =
                fileService.loadInventory(file.toString());

        assertEquals(25.00, loaded.get(0).getPrice(), 0.001);
        assertEquals(10, loaded.get(0).getQuantity());
        assertEquals("Basic sword",
                loaded.get(0).getDescription());
    }

    @Test
    public void testEmptyInventory() throws IOException {
        Path file = tempFolder.resolve("empty.json");

        fileService.saveInventory(
                file.toString(), new ArrayList<>());

        ArrayList<SalableProduct> loaded =
                fileService.loadInventory(file.toString());

        assertTrue(loaded.isEmpty());
    }

    @Test
    public void testMissingFile() {
        Path file = tempFolder.resolve("missing.json");

        assertThrows(IOException.class, () ->
                fileService.loadInventory(file.toString()));
    }

    @Test
    public void testInvalidJson() throws IOException {
        Path file = tempFolder.resolve("invalid.json");

        Files.writeString(file, "{ invalid json }");

        assertThrows(RuntimeException.class, () ->
                fileService.loadInventory(file.toString()));
    }

    @Test
    public void testUnknownProductType() throws IOException {
        Path file = tempFolder.resolve("unknown.json");

        String json =
                "[{\"type\":\"Unknown\",\"name\":\"Item\","
                + "\"description\":\"Test\",\"price\":10,"
                + "\"quantity\":5}]";

        Files.writeString(file, json);

        assertThrows(JsonParseException.class, () ->
                fileService.loadInventory(file.toString()));
    }
}
