
package app;

/**
 * Represents a product sold in the Game Store.
 * Stores the product name, description, price,
 * quantity, and purchased quantity.
 */
public class SalableProduct {

    private String name;
    private String description;
    private double price;
    private int quantity;
    private int purchasedQuantity = 0;

    /**
     * Creates a salable product.
     *
     * @param name Name of the product
     * @param description Description of the product
     * @param price Price of the product
     * @param quantity Quantity available
     */
    public SalableProduct(String name, String description,
            double price, int quantity) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }

    /**
     * Gets the product name.
     *
     * @return Product name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the product description.
     *
     * @return Product description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Gets the product price.
     *
     * @return Product price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Gets the available quantity.
     *
     * @return Available quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Updates the available quantity.
     *
     * @param quantity New quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Gets the number of purchased products.
     *
     * @return Purchased quantity
     */
    public int getPurchasedQuantity() {
        return purchasedQuantity;
    }

    /**
     * Updates the purchased quantity.
     *
     * @param purchasedQuantity New purchased quantity
     */
    public void setPurchasedQuantity(int purchasedQuantity) {
        this.purchasedQuantity = purchasedQuantity;
    }
}
