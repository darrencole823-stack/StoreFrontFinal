
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the Health class.
 */
public class HealthTest {

    @Test
    public void testHealthName() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertEquals("Potion", health.getName());
    }

    @Test
    public void testHealthDescription() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertEquals("Restores health", health.getDescription());
    }

    @Test
    public void testHealthPrice() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertEquals(15.00, health.getPrice(), 0.001);
    }

    @Test
    public void testHealthQuantity() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertEquals(10, health.getQuantity());

        health.setQuantity(5);

        assertEquals(5, health.getQuantity());
    }

    @Test
    public void testPurchasedQuantity() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertEquals(0, health.getPurchasedQuantity());

        health.setPurchasedQuantity(2);

        assertEquals(2, health.getPurchasedQuantity());
    }

    @Test
    public void testHealthInheritance() {
        Health health = new Health(
                "Potion", "Restores health", 15.00, 10);

        assertInstanceOf(SalableProduct.class, health);
    }
}
