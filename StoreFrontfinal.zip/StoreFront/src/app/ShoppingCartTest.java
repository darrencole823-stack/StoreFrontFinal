
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the ShoppingCart class.
 */
public class ShoppingCartTest {

    private ShoppingCart cart;
    private SalableProduct sword;
    private SalableProduct shield;

    @BeforeEach
    public void setUp() {
        cart = new ShoppingCart();

        sword = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        shield = new Armor(
                "Shield", "Basic shield", 30.00, 5);
    }

    @Test
    public void testInitializeCart() {
        cart.addProduct(sword);
        cart.initializeCart();

        assertEquals(0, cart.getCart().size());
    }

    @Test
    public void testAddProduct() {
        cart.addProduct(sword);

        assertEquals(1, cart.getCart().size());
        assertTrue(cart.getCart().contains(sword));
    }

    @Test
    public void testAddMultipleProducts() {
        cart.addProduct(sword);
        cart.addProduct(shield);

        assertEquals(2, cart.getCart().size());
    }

    @Test
    public void testRemoveProduct() {
        cart.addProduct(sword);
        cart.addProduct(shield);

        cart.removeProduct(sword);

        assertEquals(1, cart.getCart().size());
        assertFalse(cart.getCart().contains(sword));
    }

    @Test
    public void testRemoveProductNotInCart() {
        cart.addProduct(sword);

        cart.removeProduct(shield);

        assertEquals(1, cart.getCart().size());
    }

    @Test
    public void testGetCart() {
        cart.addProduct(sword);

        assertNotNull(cart.getCart());
        assertEquals(sword, cart.getCart().get(0));
    }

    @Test
    public void testEmptyCart() {
        cart.addProduct(sword);
        cart.addProduct(shield);

        cart.emptyCart();

        assertTrue(cart.getCart().isEmpty());
    }

    @Test
    public void testEmptyCartAlreadyEmpty() {
        cart.emptyCart();

        assertEquals(0, cart.getCart().size());
    }
}
