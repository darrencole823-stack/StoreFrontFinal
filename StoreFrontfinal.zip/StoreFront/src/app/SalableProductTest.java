
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the SalableProduct class.
 */
public class SalableProductTest {

    @Test
    public void testProductName() {
        SalableProduct product = new SalableProduct(
                "Sword", "Basic weapon", 25.00, 10);

        assertEquals("Sword", product.getName());
    }

    @Test
    public void testProductDescription() {
        SalableProduct product = new SalableProduct(
                "Sword", "Basic weapon", 25.00, 10);

        assertEquals("Basic weapon", product.getDescription());
    }

    @Test
    public void testProductPrice() {
        SalableProduct product = new SalableProduct(
                "Sword", "Basic weapon", 25.00, 10);

        assertEquals(25.00, product.getPrice(), 0.001);
    }

    @Test
    public void testProductQuantity() {
        SalableProduct product = new SalableProduct(
                "Sword", "Basic weapon", 25.00, 10);

        assertEquals(10, product.getQuantity());

        product.setQuantity(5);

        assertEquals(5, product.getQuantity());
    }

    @Test
    public void testPurchasedQuantity() {
        SalableProduct product = new SalableProduct(
                "Sword", "Basic weapon", 25.00, 10);

        assertEquals(0, product.getPurchasedQuantity());

        product.setPurchasedQuantity(2);

        assertEquals(2, product.getPurchasedQuantity());
    }
}
