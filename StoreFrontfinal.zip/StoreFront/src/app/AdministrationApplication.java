
package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * Administration Application for the Game Store.
 * Sends commands to the Store Front over the network.
 */
public class AdministrationApplication {

    /**
     * Starts the Administration Application.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int choice = 0;

        System.out.println("Welcome to the Administration Application!");

        while (choice != 3) {

            System.out.println("\n1. Update Inventory (U)");
            System.out.println("2. Retrieve Inventory (R)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            if (!input.hasNextInt()) {
                System.out.println("Invalid entry.");
                input.next();
                continue;
            }

            choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {

                System.out.println("Enter new product JSON:");
                String json = input.nextLine();

                sendCommand("U", json);

            } else if (choice == 2) {

                sendCommand("R", null);

            } else if (choice == 3) {

                System.out.println(
                        "Exiting Administration Application.");

            } else {

                System.out.println("Invalid choice.");
            }
        }

        input.close();
    }

    /**
     * Sends a command to the Administration Service.
     *
     * @param command Administration command
     * @param json JSON product data for updates
     */
    public static void sendCommand(String command, String json) {

        try (Socket socket = new Socket("localhost", 5000);

             PrintWriter output = new PrintWriter(
                     socket.getOutputStream(), true);

             BufferedReader response = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()))) {

            output.println(command);

            if (command.equalsIgnoreCase("U") && json != null) {
                output.println(json);
            }

            String result = response.readLine();

            System.out.println("\nServer Response:");
            System.out.println(result);

        } catch (IOException e) {

            System.out.println(
                    "Unable to connect to Administration Service: "
                            + e.getMessage());
        }
    }
}
