
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the Armor class.
 */
public class ArmorTest {

    @Test
    public void testArmorName() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertEquals("Shield", armor.getName());
    }

    @Test
    public void testArmorDescription() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertEquals("Basic shield", armor.getDescription());
    }

    @Test
    public void testArmorPrice() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertEquals(30.00, armor.getPrice(), 0.001);
    }

    @Test
    public void testArmorQuantity() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertEquals(10, armor.getQuantity());

        armor.setQuantity(5);

        assertEquals(5, armor.getQuantity());
    }

    @Test
    public void testPurchasedQuantity() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertEquals(0, armor.getPurchasedQuantity());

        armor.setPurchasedQuantity(2);

        assertEquals(2, armor.getPurchasedQuantity());
    }

    @Test
    public void testArmorInheritance() {
        Armor armor = new Armor(
                "Shield", "Basic shield", 30.00, 10);

        assertInstanceOf(SalableProduct.class, armor);
    }
}
