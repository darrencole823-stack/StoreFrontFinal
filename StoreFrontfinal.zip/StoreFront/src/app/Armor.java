
package app;

/**
 * Represents armor sold in the Game Store.
 * Extends the SalableProduct class.
 */
public class Armor extends SalableProduct {

    /**
     * Creates an armor product.
     *
     * @param name Name of the armor
     * @param description Description of the armor
     * @param price Price of the armor
     * @param quantity Quantity available
     */
    public Armor(String name, String description,
            double price, int quantity) {

        super(name, description, price, quantity);
    }
}
