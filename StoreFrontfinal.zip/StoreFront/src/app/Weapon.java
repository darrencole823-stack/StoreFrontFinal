package app;

/**
 * Represents a weapon sold in the store.
 */
public class Weapon extends SalableProduct implements Comparable<Weapon> {

    /**
     * Creates a weapon.
     *
     * @param name Weapon name
     * @param description Weapon description
     * @param price Weapon price
     * @param quantity Weapon quantity
     */
    public Weapon(String name, String description, double price, int quantity) {
        super(name, description, price, quantity);
    }

    /**
     * Compares weapons by name, ignoring uppercase and lowercase.
     *
     * @param other Weapon to compare
     * @return Result of comparison
     */
    @Override
    public int compareTo(Weapon other) {
        return this.getName().compareToIgnoreCase(other.getName());
    }
}