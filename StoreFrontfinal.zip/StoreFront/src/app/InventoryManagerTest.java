
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

/**
 * JUnit tests for the InventoryManager class.
 */
public class InventoryManagerTest {

    private InventoryManager inventory;
    private SalableProduct sword;
    private SalableProduct shield;
    private SalableProduct potion;

    @BeforeEach
    public void setUp() {
        inventory = new InventoryManager();

        sword = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        shield = new Armor(
                "Shield", "Basic shield", 30.00, 5);

        potion = new Health(
                "Potion", "Restores health", 15.00, 20);

        inventory.addProduct(sword);
        inventory.addProduct(shield);
        inventory.addProduct(potion);
    }

    @Test
    public void testAddProduct() {
        assertEquals(3, inventory.getInventory().size());
    }

    @Test
    public void testRemoveProduct() {
        inventory.removeProduct(sword);

        assertEquals(2, inventory.getInventory().size());
        assertFalse(inventory.getInventory().contains(sword));
    }

    @Test
    public void testGetProduct() {
        assertEquals(sword, inventory.getProduct(1));
        assertEquals(shield, inventory.getProduct(2));
        assertEquals(potion, inventory.getProduct(3));
    }

    @Test
    public void testInvalidProductNumber() {
        assertNull(inventory.getProduct(0));
        assertNull(inventory.getProduct(10));
        assertNull(inventory.getProduct(-1));
    }

    @Test
    public void testSortNameAscending() {
        inventory.sortNameAscending();

        assertEquals("Potion",
                inventory.getProduct(1).getName());
        assertEquals("Shield",
                inventory.getProduct(2).getName());
        assertEquals("Sword",
                inventory.getProduct(3).getName());
    }

    @Test
    public void testSortNameDescending() {
        inventory.sortNameDescending();

        assertEquals("Sword",
                inventory.getProduct(1).getName());
        assertEquals("Shield",
                inventory.getProduct(2).getName());
        assertEquals("Potion",
                inventory.getProduct(3).getName());
    }

    @Test
    public void testSortPriceAscending() {
        inventory.sortPriceAscending();

        assertEquals(15.00,
                inventory.getProduct(1).getPrice(), 0.001);
        assertEquals(25.00,
                inventory.getProduct(2).getPrice(), 0.001);
        assertEquals(30.00,
                inventory.getProduct(3).getPrice(), 0.001);
    }

    @Test
    public void testSortPriceDescending() {
        inventory.sortPriceDescending();

        assertEquals(30.00,
                inventory.getProduct(1).getPrice(), 0.001);
        assertEquals(25.00,
                inventory.getProduct(2).getPrice(), 0.001);
        assertEquals(15.00,
                inventory.getProduct(3).getPrice(), 0.001);
    }

    @Test
    public void testGetInventory() {
        ArrayList<SalableProduct> products =
                inventory.getInventory();

        assertNotNull(products);
        assertEquals(3, products.size());
    }

    @Test
    public void testDisplayInventory() {
        assertDoesNotThrow(() ->
                inventory.displayInventory());
    }
}
