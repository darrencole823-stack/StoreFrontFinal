
package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Administration Service for the Game Store.
 * Handles inventory updates and retrieval over the network.
 */
public class AdminService implements Runnable {

    private InventoryManager inventoryManager;
    private FileService fileService;
    private int port;

    /**
     * Creates the Administration Service.
     *
     * @param inventoryManager Store inventory manager
     * @param port Network port number
     */
    public AdminService(
            InventoryManager inventoryManager, int port) {

        this.inventoryManager = inventoryManager;
        this.fileService = new FileService();
        this.port = port;
    }

    /**
     * Starts the Administration Service.
     */
    @Override
    public void run() {

        try (ServerSocket serverSocket = new ServerSocket(port)) {

            System.out.println(
                    "Administration Service started on port " + port);

            while (!Thread.currentThread().isInterrupted()) {

                try (Socket clientSocket = serverSocket.accept();

                     BufferedReader input = new BufferedReader(
                             new InputStreamReader(
                                     clientSocket.getInputStream()));

                     PrintWriter output = new PrintWriter(
                             clientSocket.getOutputStream(), true)) {

                    String command = input.readLine();

                    if (command == null) {
                        continue;
                    }

                    Gson gson = new Gson();

                    if (command.equalsIgnoreCase("R")) {

                        ArrayList<SalableProduct> products =
                                inventoryManager.getInventory();

                        output.println(gson.toJson(products));

                    } else if (command.equalsIgnoreCase("U")) {

                        String json = input.readLine();

                        if (json == null || json.trim().isEmpty()) {
                            output.println("ERROR: No JSON data received.");
                            continue;
                        }

                        try {
                            JsonArray jsonArray =
                                    JsonParser.parseString(json)
                                            .getAsJsonArray();

                            ArrayList<SalableProduct> newProducts =
                                    new ArrayList<>();

                            for (JsonElement element : jsonArray) {

                                JsonObject object =
                                        element.getAsJsonObject();

                                String type =
                                        object.get("type").getAsString();

                                SalableProduct product;

                                if (type.equalsIgnoreCase("Weapon")) {

                                    product = gson.fromJson(
                                            object, Weapon.class);

                                } else if (type.equalsIgnoreCase("Armor")) {

                                    product = gson.fromJson(
                                            object, Armor.class);

                                } else if (type.equalsIgnoreCase("Health")) {

                                    product = gson.fromJson(
                                            object, Health.class);

                                } else {
                                    throw new IllegalArgumentException(
                                            "Unknown product type: " + type);
                                }

                                newProducts.add(product);
                            }

                            ArrayList<SalableProduct> updatedInventory =
                                    new ArrayList<>(
                                            inventoryManager.getInventory());

                            updatedInventory.addAll(newProducts);

                            fileService.saveInventory(
                                    "inventory.json", updatedInventory);

                            inventoryManager.getInventory().addAll(
                                    newProducts);

                            output.println(
                                    "Inventory updated successfully.");

                        } catch (IOException | RuntimeException e) {

                            output.println(
                                    "ERROR: " + e.getMessage());
                        }

                    } else {

                        output.println("ERROR: Unknown command.");
                    }

                } catch (IOException e) {

                    System.out.println(
                            "Administration connection error: "
                                    + e.getMessage());
                }
            }

        } catch (IOException e) {

            System.out.println(
                    "Administration Service error: "
                            + e.getMessage());
        }
    }
}
