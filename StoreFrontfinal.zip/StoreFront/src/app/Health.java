
package app;

/**
 * Represents a health product sold in the Game Store.
 * Extends the SalableProduct class.
 */
public class Health extends SalableProduct {

    /**
     * Creates a health product.
     *
     * @param name Name of the health product
     * @param description Description of the health product
     * @param price Price of the health product
     * @param quantity Quantity available
     */
    public Health(String name, String description,
            double price, int quantity) {

        super(name, description, price, quantity);
    }
}
