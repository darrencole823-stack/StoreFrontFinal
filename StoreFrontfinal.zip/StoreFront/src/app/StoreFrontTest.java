
package app;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the StoreFront application.
 */
public class StoreFrontTest {

    /**
     * Runs StoreFront with simulated user input.
     * Captures the output to check the results.
     */
    private String runStoreFront(String commands) {

        InputStream originalInput = System.in;
        PrintStream originalOutput = System.out;

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        try {
            System.setIn(new ByteArrayInputStream(
                    commands.getBytes(StandardCharsets.UTF_8)));

            System.setOut(new PrintStream(output));

            StoreFront.main(new String[0]);

            return output.toString();

        } finally {
            System.setIn(originalInput);
            System.setOut(originalOutput);
        }
    }

    @Test
    public void testWelcomeMessage() {
        String output = runStoreFront("9\n");

        assertTrue(output.contains(
                "Welcome to the Game Store!"));
    }

    @Test
    public void testExitStore() {
        String output = runStoreFront("9\n");

        assertTrue(output.contains(
                "Thank you for visiting the Game Store!"));
    }

    @Test
    public void testViewInventory() {
        String output = runStoreFront("1\n9\n");

        assertTrue(output.contains("View Inventory"));
        assertTrue(output.contains("Enter your choice:"));
    }

    @Test
    public void testEmptyShoppingCart() {
        String output = runStoreFront("4\n9\n");

        assertTrue(output.contains(
                "Your shopping cart is empty."));
    }

    @Test
    public void testCancelEmptyCart() {
        String output = runStoreFront("3\n9\n");

        assertTrue(output.contains(
                "Your shopping cart is empty."));
    }

    @Test
    public void testInvalidMenuChoice() {
        String output = runStoreFront("15\n9\n");

        assertTrue(output.contains(
                "Invalid choice. Please try again."));
    }

    @Test
    public void testInvalidTextInput() {
        String output = runStoreFront("abc\n9\n");

        assertTrue(output.contains(
                "Invalid entry. Please enter a number."));
    }

    @Test
    public void testInvalidPurchaseNumber() {
        String output = runStoreFront("2\n999\n9\n");

        assertTrue(output.contains(
                "Product not found."));
    }

    @Test
    public void testInvalidPurchaseText() {
        String output = runStoreFront("2\nabc\n9\n");

        assertTrue(output.contains(
                "Invalid product number."));
    }

    @Test
    public void testSortNameAscending() {
        String output = runStoreFront("5\n9\n");

        assertTrue(output.contains(
                "Products sorted by name A to Z."));
    }

    @Test
    public void testSortNameDescending() {
        String output = runStoreFront("6\n9\n");

        assertTrue(output.contains(
                "Products sorted by name Z to A."));
    }

    @Test
    public void testSortPriceAscending() {
        String output = runStoreFront("7\n9\n");

        assertTrue(output.contains(
                "Products sorted by price Low to High."));
    }

    @Test
    public void testSortPriceDescending() {
        String output = runStoreFront("8\n9\n");

        assertTrue(output.contains(
                "Products sorted by price High to Low."));
    }
}
