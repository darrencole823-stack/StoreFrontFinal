
package app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.google.gson.JsonParseException;

/**
 * Manages the store inventory.
 */
public class InventoryManager {

    private ArrayList<SalableProduct> inventory = new ArrayList<>();

    /**
     * Initializes the store inventory using an external JSON file.
     */
    public void initializeInventory() {

        FileService fileService = new FileService();

        try {
            inventory = fileService.loadInventory("inventory.json");
            System.out.println("Inventory loaded successfully.");

        } catch (IOException e) {
            System.out.println("Error reading inventory file: "
                    + e.getMessage());

        } catch (JsonParseException | IllegalStateException e) {
            System.out.println("Error processing inventory JSON: "
                    + e.getMessage());
        }
    }

    /**
     * Adds a product to the inventory.
     *
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) {
        inventory.add(product);
    }

    /**
     * Removes a product from the inventory.
     *
     * @param product Product to remove
     */
    public void removeProduct(SalableProduct product) {
        inventory.remove(product);
    }

    /**
     * Sorts products by name in ascending order.
     */
    public void sortNameAscending() {
        Collections.sort(inventory,
                Comparator.comparing(SalableProduct::getName));
    }

    /**
     * Sorts products by name in descending order.
     */
    public void sortNameDescending() {
        Collections.sort(inventory,
                Comparator.comparing(
                        SalableProduct::getName).reversed());
    }

    /**
     * Sorts products by price in ascending order.
     */
    public void sortPriceAscending() {
        Collections.sort(inventory,
                Comparator.comparingDouble(SalableProduct::getPrice));
    }

    /**
     * Sorts products by price in descending order.
     */
    public void sortPriceDescending() {
        Collections.sort(inventory,
                Comparator.comparingDouble(
                        SalableProduct::getPrice).reversed());
    }

    /**
     * Displays all products in the inventory.
     */
    public void displayInventory() {

        for (int i = 0; i < inventory.size(); i++) {

            SalableProduct product = inventory.get(i);

            System.out.println((i + 1) + ". " + product.getName());
            System.out.println("Description: " + product.getDescription());
            System.out.println("Price: $" + product.getPrice());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println();
        }
    }

    /**
     * Returns a product based on its number.
     *
     * @param number Product number
     * @return Selected product or null if not found
     */
    public SalableProduct getProduct(int number) {

        if (number >= 1 && number <= inventory.size()) {
            return inventory.get(number - 1);
        }

        return null;
    }

    /**
     * Returns the entire inventory.
     *
     * @return List of products
     */
    public ArrayList<SalableProduct> getInventory() {
        return inventory;
    }
}
