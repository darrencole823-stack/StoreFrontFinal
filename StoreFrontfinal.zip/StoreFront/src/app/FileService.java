
package app;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonParseException;

/**
 * Handles reading and writing inventory JSON files.
 */
public class FileService {

    /**
     * Loads products from an external JSON file.
     *
     * @param fileName Name of the JSON file
     * @return List of products
     * @throws IOException If the file cannot be read
     * @throws JsonParseException If the JSON is invalid
     */
    public ArrayList<SalableProduct> loadInventory(String fileName)
            throws IOException, JsonParseException {

        ArrayList<SalableProduct> products = new ArrayList<>();
        Gson gson = new Gson();

        try (FileReader reader = new FileReader(fileName)) {

            JsonElement data = JsonParser.parseReader(reader);
            JsonArray inventory = data.getAsJsonArray();

            for (JsonElement element : inventory) {

                JsonObject object = element.getAsJsonObject();
                String type = object.get("type").getAsString();

                SalableProduct product;

                if (type.equalsIgnoreCase("Weapon")) {
                    product = gson.fromJson(object, Weapon.class);

                } else if (type.equalsIgnoreCase("Armor")) {
                    product = gson.fromJson(object, Armor.class);

                } else if (type.equalsIgnoreCase("Health")) {
                    product = gson.fromJson(object, Health.class);

                } else {
                    throw new JsonParseException(
                            "Unknown product type: " + type);
                }

                products.add(product);
            }
        }

        return products;
    }

    /**
     * Saves inventory products to a JSON file.
     *
     * @param fileName Name of the JSON file
     * @param products List of products to save
     * @throws IOException If the file cannot be written
     */
    public void saveInventory(String fileName,
            ArrayList<SalableProduct> products) throws IOException {

        Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        JsonArray inventory = new JsonArray();

        for (SalableProduct product : products) {

            JsonObject object =
                    gson.toJsonTree(product).getAsJsonObject();

            if (product instanceof Weapon) {
                object.addProperty("type", "Weapon");

            } else if (product instanceof Armor) {
                object.addProperty("type", "Armor");

            } else if (product instanceof Health) {
                object.addProperty("type", "Health");
            }

            inventory.add(object);
        }

        try (FileWriter writer = new FileWriter(fileName)) {
            gson.toJson(inventory, writer);
        }
    }
}
