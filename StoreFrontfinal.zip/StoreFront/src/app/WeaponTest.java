
package app;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the Weapon class.
 */
public class WeaponTest {

    @Test
    public void testWeaponName() {
        Weapon weapon = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        assertEquals("Sword", weapon.getName());
    }

    @Test
    public void testWeaponDescription() {
        Weapon weapon = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        assertEquals("Basic sword", weapon.getDescription());
    }

    @Test
    public void testWeaponPrice() {
        Weapon weapon = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        assertEquals(25.00, weapon.getPrice(), 0.001);
    }

    @Test
    public void testWeaponQuantity() {
        Weapon weapon = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        assertEquals(10, weapon.getQuantity());

        weapon.setQuantity(5);

        assertEquals(5, weapon.getQuantity());
    }

    @Test
    public void testWeaponComparison() {
        Weapon sword = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        Weapon axe = new Weapon(
                "Axe", "Basic axe", 20.00, 5);

        assertTrue(sword.compareTo(axe) > 0);
        assertTrue(axe.compareTo(sword) < 0);
    }

    @Test
    public void testWeaponComparisonIgnoreCase() {
        Weapon sword1 = new Weapon(
                "Sword", "Basic sword", 25.00, 10);

        Weapon sword2 = new Weapon(
                "sword", "Basic sword", 25.00, 10);

        assertEquals(0, sword1.compareTo(sword2));
    }
}
